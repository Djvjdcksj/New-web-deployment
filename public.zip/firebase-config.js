// firebase-config.js
import { initializeApp } from "https://www.gstatic.com/firebasejs/10.12.5/firebase-app.js";
import { getAuth } from "https://www.gstatic.com/firebasejs/10.12.5/firebase-auth.js";

const firebaseConfig = {
  apiKey: "AIzaSyCmREFy4eW6HlcWMWdM6NtvEKrdNyIutr4",
  authDomain: "earn-app-d8126.firebaseapp.com",
  projectId: "earn-app-d8126",
  storageBucket: "earn-app-d8126.appspot.com",
  messagingSenderId: "900926113599",
  appId: "1:900926113599:web:3cd7f1099147a6c5cab58a",
  measurementId: "G-LCD5LPCSC7"
};

const app = initializeApp(firebaseConfig);
const auth = getAuth(app);

export { auth };